import React from 'react'

function Resume() {
    return (
        <div class="resume-section">
            <iframe class = "pdf" src="pdf/SohamParikh_CV.pdf" frameborder="0">
            </iframe>
        </div>
    )

}

export default Resume;
